package Gabriel_Lincoln_Questao10;

public class TesteNotas {
    public static void main(String[] args) {
        Notas notas = new Notas(7.5, 8.0, 9.0, 7.0, 8.5, 9.5);
        notas.calculaMediaFinal();
    }
}
