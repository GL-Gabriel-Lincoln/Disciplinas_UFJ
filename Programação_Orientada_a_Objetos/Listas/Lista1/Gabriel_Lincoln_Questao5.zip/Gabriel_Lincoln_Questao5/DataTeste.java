package Gabriel_Lincoln_Questao5;

public class DataTeste {
    public static void main(String[] args) {
        Data data = new Data(31, 12, 2022);
        data.exibeData();
    }
}
