package Gabriel_Lincoln_Questao1;

public class CalculadoraCompleta extends Calculadora {
    public double raizQuadrada(double a) {
        return Math.sqrt(a);
    }

    public double potenciaAoQuadrado(double a) {
        return Math.pow(a, 2);
    }
}
